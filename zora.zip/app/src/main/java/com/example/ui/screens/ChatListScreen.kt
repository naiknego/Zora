package com.example.ui.screens

import android.text.format.DateUtils
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ChatSession

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatListScreen(
    sessions: List<ChatSession>,
    onSessionSelected: (String) -> Unit,
    onNewChatClicked: () -> Unit,
    onSettingsClicked: () -> Unit,
    onDeleteSession: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }

    val filteredSessions = remember(sessions, searchQuery) {
        if (searchQuery.isBlank()) {
            sessions
        } else {
            sessions.filter { it.title.contains(searchQuery, ignoreCase = true) }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Soft background glow layers matching RikkaHub's premium ambient aesthetic
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .alpha(0.18f)
        ) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF7B2CBF), Color.Transparent),
                    radius = size.width * 0.85f
                ),
                radius = size.width * 0.85f,
                center = androidx.compose.ui.geometry.Offset(size.width * 0.9f, size.height * 0.15f)
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFFF72585), Color.Transparent),
                    radius = size.width * 0.65f
                ),
                radius = size.width * 0.65f,
                center = androidx.compose.ui.geometry.Offset(size.width * 0.1f, size.height * 0.85f)
            )
        }

        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                LargeTopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "RikkaHub",
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp,
                                fontSize = 30.sp,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            // Breathing glowing status indicator dot
                            val infiniteTransition = rememberInfiniteTransition(label = "pulse")
                            val pulseAlpha by infiniteTransition.animateFloat(
                                initialValue = 0.4f,
                                targetValue = 1.0f,
                                animationSpec = infiniteRepeatable(
                                    animation = tween(1000, easing = EaseInOutSine),
                                    repeatMode = RepeatMode.Reverse
                                ),
                                label = "dotPulse"
                            )
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF00F5D4)),
                                shape = RoundedCornerShape(50),
                                modifier = Modifier
                                    .size(10.dp)
                                    .alpha(pulseAlpha)
                                    .border(2.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(50))
                            ) {}
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = onSettingsClicked,
                            modifier = Modifier
                                .testTag("settings_button")
                                .padding(end = 8.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Settings,
                                contentDescription = "Settings",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    },
                    colors = TopAppBarDefaults.largeTopAppBarColors(
                        containerColor = Color.Transparent,
                        scrolledContainerColor = Color.Transparent
                    )
                )
            },
            floatingActionButton = {
                // Highly polished cyber gradient FAB
                ExtendedFloatingActionButton(
                    onClick = onNewChatClicked,
                    modifier = Modifier
                        .testTag("new_chat_fab")
                        .padding(8.dp)
                        .border(
                            width = 1.dp,
                            brush = Brush.linearGradient(
                                colors = listOf(Color.White.copy(alpha = 0.3f), Color.Transparent)
                            ),
                            shape = RoundedCornerShape(18.dp)
                        ),
                    containerColor = Color.Transparent,
                    contentColor = Color.White,
                    shape = RoundedCornerShape(18.dp),
                    elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .background(
                                brush = Brush.horizontalGradient(
                                    colors = listOf(Color(0xFF7B2CBF), Color(0xFFF72585))
                                )
                            )
                            .padding(horizontal = 20.dp, vertical = 14.dp)
                            .fillMaxHeight(),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = "New Chat")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = "New Chat", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                        }
                    }
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // Elegant styled search bar with thin outline and modern touch
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search chats...", color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    },
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .border(
                            1.dp,
                            MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f),
                            RoundedCornerShape(20.dp)
                        )
                        .testTag("search_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.3f),
                        focusedBorderColor = Color(0xFF7B2CBF),
                        unfocusedBorderColor = Color.Transparent
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                if (filteredSessions.isEmpty()) {
                    val title = if (searchQuery.isNotEmpty()) "No results found" else "No conversations yet"
                    val desc = if (searchQuery.isNotEmpty()) {
                        "Try checking your spelling or searching for another chat title."
                    } else {
                        "RikkaHub is ready to help you with reasoning, coding, and creative prompts. Tap 'New Chat' to begin!"
                    }
                    EmptyState(
                        title = title,
                        description = desc,
                        iconString = "✨",
                        modifier = Modifier.weight(1f)
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f),
                        contentPadding = PaddingValues(start = 16.dp, top = 8.dp, end = 16.dp, bottom = 90.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        itemsIndexed(filteredSessions, key = { _, session -> session.id }) { index, session ->
                            AnimatedChatSessionItem(
                                index = index,
                                session = session,
                                onClick = { onSessionSelected(session.id) },
                                onDelete = { onDeleteSession(session.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AnimatedChatSessionItem(
    index: Int,
    session: ChatSession,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    val scale = remember { Animatable(0.93f) }
    val opacity = remember { Animatable(0f) }

    LaunchedEffect(key1 = session.id) {
        val delay = (index * 40).coerceAtMost(250)
        kotlinx.coroutines.delay(delay.toLong())
        scale.animateTo(1.0f, animationSpec = tween(durationMillis = 350, easing = EaseOutBack))
    }
    LaunchedEffect(key1 = session.id) {
        val delay = (index * 40).coerceAtMost(250)
        kotlinx.coroutines.delay(delay.toLong())
        opacity.animateTo(1.0f, animationSpec = tween(durationMillis = 250))
    }

    Box(
        modifier = Modifier.graphicsLayer(
            scaleX = scale.value,
            scaleY = scale.value,
            alpha = opacity.value
        )
    ) {
        ChatSessionItem(
            session = session,
            onClick = onClick,
            onDelete = onDelete
        )
    }
}

@Composable
fun ChatSessionItem(
    session: ChatSession,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    var showDeleteConfirm by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f),
                shape = RoundedCornerShape(20.dp)
            )
            .testTag("session_card_${session.id}"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.55f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Session Title
                    Text(
                        text = session.title,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    // Styled Mode Pill
                    val pillColor = if (session.mode == "thinking") {
                        Color(0xFF2D1E4E)
                    } else {
                        Color(0xFF0F362C)
                    }
                    val textColor = if (session.mode == "thinking") {
                        Color(0xFFE0AAFF)
                    } else {
                        Color(0xFF00F5D4)
                    }
                    val pillText = if (session.mode == "thinking") "🧠 Reasoning" else "⚡ Fast"
                    
                    Card(
                        colors = CardDefaults.cardColors(containerColor = pillColor),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.border(0.5.dp, textColor.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                    ) {
                        Text(
                            text = pillText,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = textColor,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Relative last active time
                val relativeTime = DateUtils.getRelativeTimeSpanString(
                    session.lastMessageAt,
                    System.currentTimeMillis(),
                    DateUtils.MINUTE_IN_MILLIS
                ).toString()

                Text(
                    text = "Active $relativeTime",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Smooth confirm delete actions
            if (showDeleteConfirm) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    TextButton(onClick = { showDeleteConfirm = false }) {
                        Text("Keep", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Button(
                        onClick = {
                            showDeleteConfirm = false
                            onDelete()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFF72585)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text("Delete", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                    }
                }
            } else {
                IconButton(
                    onClick = { showDeleteConfirm = true },
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
                ) {
                    Icon(
                        imageVector = Icons.Outlined.DeleteOutline,
                        contentDescription = "Delete Session",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
