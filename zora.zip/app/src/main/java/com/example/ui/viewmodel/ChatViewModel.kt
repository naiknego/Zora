package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class ChatViewModel(
    application: Application,
    private val repository: ChatRepository
) : AndroidViewModel(application) {

    // Default configuration constants
    companion object {
        const val KEY_API_KEY = "api_key"
        const val KEY_BASE_ENDPOINT = "base_endpoint"
        const val KEY_FAST_MODEL = "fast_model"
        const val KEY_THINKING_MODEL = "thinking_model"
        const val KEY_FAST_SYSTEM_PROMPT = "fast_system_prompt"
        const val KEY_THINKING_SYSTEM_PROMPT = "thinking_system_prompt"

        const val KEY_SEARCH_SERVICE_TYPE = "search_service_type"
        const val KEY_SEARCH_SERVICE_KEY = "search_service_key"
        const val KEY_SPEECH_TTS_PROVIDER = "speech_tts_provider"
        const val KEY_SPEECH_STT_PROVIDER = "speech_stt_provider"
        const val KEY_MCP_SERVERS_JSON = "mcp_servers_json"
        const val KEY_WEB_SERVER_ENABLED = "web_server_enabled"

        const val DEFAULT_API_KEY = "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"
        const val DEFAULT_BASE_ENDPOINT = "https://openrouter.ai/api/v1/chat/completions"
        const val DEFAULT_FAST_MODEL = "openai/gpt-oss-20b:free"
        const val DEFAULT_THINKING_MODEL = "openai/gpt-oss-120b:free"

        val DEFAULT_FAST_PROMPT_VAL = """
            ## Identity
            You are a fast, efficient AI assistant. Your goal is to deliver **quick, concise, and direct answers**.

            ## Core Rules
            - **Answer immediately** without lengthy preambles or over-explanation.
            - Keep responses **short and to the point** (max 3–5 sentences unless more is needed).
            - Use **bullet points** for lists instead of long paragraphs.
            - **Skip unnecessary filler phrases** like "Great question!" or "Of course!".
            - If the answer is simple, give it in **one line**.
            - Prioritize **clarity over completeness** — give the most useful answer fast.

            ## Tone
            - Direct, confident, and friendly.
            - No fluff. No repetition.

            ## Format
            - Use markdown when helpful (lists, bold, code blocks).
            - Avoid walls of text.
            - If unsure, give the best answer and flag uncertainty briefly.

            ## Goal
            > Get the user what they need as fast as possible.
        """.trimIndent()

        val DEFAULT_THINKING_PROMPT_VAL = """
            # THINKING MODE — AI Assistant

            ## Identity
            You are a deep-thinking AI assistant. Your goal is to **reason carefully, analyze thoroughly, and provide well-structured, insightful answers**.

            ## Core Rules
            - **Think step by step** before answering. Break down complex problems.
            - Show your **reasoning process** when relevant — don't just give conclusions.
            - Consider **multiple perspectives and potential edge cases**.
            - Acknowledge **uncertainty** and nuance where it exists.
            - Provide **examples, analogies, or evidence** to support your answers.
            - If a question has multiple valid answers, **explore each one**.

            ## Reasoning Process
            1. **Understand** — Restate or clarify the question if needed.
            2. **Analyze** — Break the problem into components.
            3. **Reason** — Think through each part logically.
            4. **Synthesize** — Combine insights into a clear answer.
            5. **Reflect** — Check for errors or gaps in reasoning.

            ## Tone
            - Thoughtful, precise, and intellectually engaged.
            - Honest about limitations and assumptions.

            ## Format
            - Use headers, numbered steps, and structured sections.
            - Long-form responses are acceptable and encouraged when depth is needed.
            - Use code blocks, tables, or diagrams when they aid understanding.

            ## Goal
            > Deliver the **most accurate, well-reasoned, and complete answer** possible — quality over speed.
        """.trimIndent()
    }

    // Sessions and navigation states
    val sessions: StateFlow<List<ChatSession>> = repository.allSessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentSessionId = MutableStateFlow<String?>(null)
    val currentSessionId: StateFlow<String?> = _currentSessionId.asStateFlow()

    private val _activeMode = MutableStateFlow("fast") // "fast" or "thinking"
    val activeMode: StateFlow<String> = _activeMode.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val currentMessages: StateFlow<List<ChatMessage>> = _currentSessionId
        .flatMapLatest { sessionId ->
            if (sessionId == null) {
                flowOf(emptyList())
            } else {
                repository.getMessages(sessionId)
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _isTyping = MutableStateFlow(false)
    val isTyping: StateFlow<Boolean> = _isTyping.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    // Settings state holding custom parameters
    private val _settingsMap = MutableStateFlow<Map<String, String>>(emptyMap())
    val settingsMap: StateFlow<Map<String, String>> = _settingsMap.asStateFlow()

    init {
        // Fetch and initialize settings
        viewModelScope.launch {
            repository.getAllSettingsFlow().collect { list ->
                val map = list.associate { it.key to it.value }
                _settingsMap.value = map
            }
        }
    }

    // Get helper
    fun getSettingValue(key: String, defaultValue: String): String {
        return _settingsMap.value[key] ?: defaultValue
    }

    fun saveSettingValue(key: String, value: String) {
        viewModelScope.launch {
            repository.saveSetting(key, value)
        }
    }

    fun selectSession(sessionId: String?) {
        _currentSessionId.value = sessionId
        viewModelScope.launch {
            if (sessionId != null) {
                val s = repository.getSessionById(sessionId)
                if (s != null) {
                    _activeMode.value = s.mode
                }
            }
        }
    }

    fun setMode(mode: String) {
        _activeMode.value = mode
        val sid = _currentSessionId.value
        if (sid != null) {
            viewModelScope.launch {
                val s = repository.getSessionById(sid)
                if (s != null) {
                    repository.updateSession(s.copy(mode = mode))
                }
            }
        }
    }

    fun startNewSession(onCreated: (String) -> Unit = {}) {
        viewModelScope.launch {
            val title = "New Chat " + (sessions.value.size + 1)
            val newSession = ChatSession(
                title = title,
                mode = _activeMode.value
            )
            repository.createSession(newSession)
            _currentSessionId.value = newSession.id
            onCreated(newSession.id)
        }
    }

    fun deleteSession(sessionId: String) {
        viewModelScope.launch {
            repository.deleteSession(sessionId)
            if (_currentSessionId.value == sessionId) {
                _currentSessionId.value = null
            }
        }
    }

    fun sendMessage(content: String) {
        val sessionId = _currentSessionId.value ?: return
        if (content.isBlank()) return

        _errorMessage.value = null
        viewModelScope.launch {
            // Save user message
            val userMsg = ChatMessage(
                sessionId = sessionId,
                role = "user",
                content = content
            )
            repository.saveMessage(userMsg)

            // Update session timestamp and dynamic title if it's the first message
            val currentSession = repository.getSessionById(sessionId)
            if (currentSession != null) {
                val updatedTitle = if (currentMessages.value.size <= 1) {
                    if (content.length > 25) content.take(25) + "..." else content
                } else {
                    currentSession.title
                }
                repository.updateSession(
                    currentSession.copy(
                        title = updatedTitle,
                        lastMessageAt = System.currentTimeMillis()
                    )
                )
            }

            // Create typing placeholder
            _isTyping.value = true
            val placeholderId = UUID.randomUUID().toString()
            val assistantPlaceholder = ChatMessage(
                id = placeholderId,
                sessionId = sessionId,
                role = "assistant",
                content = "...",
                isThinking = _activeMode.value == "thinking"
            )
            repository.saveMessage(assistantPlaceholder)

            try {
                // Fetch settings
                val apiKey = getSettingValue(KEY_API_KEY, DEFAULT_API_KEY)
                val baseEndpoint = getSettingValue(KEY_BASE_ENDPOINT, DEFAULT_BASE_ENDPOINT)
                val activeModel = if (_activeMode.value == "thinking") {
                    getSettingValue(KEY_THINKING_MODEL, DEFAULT_THINKING_MODEL)
                } else {
                    getSettingValue(KEY_FAST_MODEL, DEFAULT_FAST_MODEL)
                }
                val systemPrompt = if (_activeMode.value == "thinking") {
                    getSettingValue(KEY_THINKING_SYSTEM_PROMPT, DEFAULT_THINKING_PROMPT_VAL)
                } else {
                    getSettingValue(KEY_FAST_SYSTEM_PROMPT, DEFAULT_FAST_PROMPT_VAL)
                }

                // Construct message history context
                val apiMessages = mutableListOf<OpenRouterMessage>()
                apiMessages.add(OpenRouterMessage(role = "system", content = systemPrompt))

                // Get preceding 15 messages for context
                val previousList = currentMessages.value
                    .filter { it.id != placeholderId }
                    .takeLast(15)
                    .map { OpenRouterMessage(role = it.role, content = it.content) }
                apiMessages.addAll(previousList)

                // Call endpoint
                val response = repository.fetchChatCompletion(
                    endpointUrl = baseEndpoint,
                    apiKey = apiKey,
                    model = activeModel,
                    messages = apiMessages
                )

                val replyText = response.choices?.firstOrNull()?.message?.content
                    ?: "No response from AI."

                // Save final assistant response
                repository.saveMessage(
                    assistantPlaceholder.copy(
                        content = replyText,
                        isThinking = false
                    )
                )

            } catch (e: Exception) {
                e.printStackTrace()
                _errorMessage.value = "Failed to fetch response: ${e.localizedMessage ?: "Unknown network error"}"
                repository.saveMessage(
                    assistantPlaceholder.copy(
                        content = "Error: ${e.localizedMessage ?: "Connection failure. Please check settings or API Key."}",
                        isThinking = false
                    )
                )
            } finally {
                _isTyping.value = false
            }
        }
    }

    // Factory
    class Factory(
        private val application: Application,
        private val repository: ChatRepository
    ) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(ChatViewModel::class.java)) {
                @Suppress("UNCHECKED_CAST")
                return ChatViewModel(application, repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
