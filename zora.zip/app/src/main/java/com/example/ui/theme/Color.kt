package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light/Dark Theme Color Definitions - Premium Violet/Magenta Cyberpunk look matching RikkaHub
val PurplePrimary = Color(0xFF7B2CBF)
val PurpleDark = Color(0xFF3A0CA3)
val MagentaCyber = Color(0xFFF72585)

val CyberBlack = Color(0xFF090A0F)
val DarkCharcoal = Color(0xFF14151F)
val SlateGray = Color(0xFF1E202E)
val BorderAccent = Color(0xFF2E3146)

val LightPurple = Color(0xFFE0AAFF)
val IceBlue = Color(0xFF4CC9F0)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

