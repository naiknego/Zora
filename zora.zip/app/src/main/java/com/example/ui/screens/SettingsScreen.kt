package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.ChatViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: ChatViewModel,
    onBackClicked: () -> Unit,
    onAboutClicked: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = remember {
        context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    }
    val scrollState = rememberScrollState()

    // Key settings states observed from viewModel's settings map
    val settingsMap by viewModel.settingsMap.collectAsState()

    // Local states mirroring database configs
    var apiKeyInput by remember(settingsMap) {
        mutableStateOf(settingsMap[ChatViewModel.KEY_API_KEY] ?: ChatViewModel.DEFAULT_API_KEY)
    }
    var baseEndpointInput by remember(settingsMap) {
        mutableStateOf(settingsMap[ChatViewModel.KEY_BASE_ENDPOINT] ?: ChatViewModel.DEFAULT_BASE_ENDPOINT)
    }
    var fastModelInput by remember(settingsMap) {
        mutableStateOf(settingsMap[ChatViewModel.KEY_FAST_MODEL] ?: ChatViewModel.DEFAULT_FAST_MODEL)
    }
    var thinkingModelInput by remember(settingsMap) {
        mutableStateOf(settingsMap[ChatViewModel.KEY_THINKING_MODEL] ?: ChatViewModel.DEFAULT_THINKING_MODEL)
    }
    var fastPromptInput by remember(settingsMap) {
        mutableStateOf(settingsMap[ChatViewModel.KEY_FAST_SYSTEM_PROMPT] ?: ChatViewModel.DEFAULT_FAST_PROMPT_VAL)
    }
    var thinkingPromptInput by remember(settingsMap) {
        mutableStateOf(settingsMap[ChatViewModel.KEY_THINKING_SYSTEM_PROMPT] ?: ChatViewModel.DEFAULT_THINKING_PROMPT_VAL)
    }

    // Search Services
    var searchServiceType by remember(settingsMap) {
        mutableStateOf(settingsMap[ChatViewModel.KEY_SEARCH_SERVICE_TYPE] ?: "None")
    }
    var searchServiceKey by remember(settingsMap) {
        mutableStateOf(settingsMap[ChatViewModel.KEY_SEARCH_SERVICE_KEY] ?: "")
    }

    // Speech Services
    var speechTtsProvider by remember(settingsMap) {
        mutableStateOf(settingsMap[ChatViewModel.KEY_SPEECH_TTS_PROVIDER] ?: "SystemDefault")
    }
    var speechSttProvider by remember(settingsMap) {
        mutableStateOf(settingsMap[ChatViewModel.KEY_SPEECH_STT_PROVIDER] ?: "SystemDefault")
    }

    // MCP
    var mcpServersJson by remember(settingsMap) {
        val defaultJson = """
        {
          "mcp_servers": {
            "filesystem": {
              "command": "npx",
              "args": ["-y", "@modelcontextprotocol/server-filesystem", "/workspace"]
            },
            "github": {
              "command": "npx",
              "args": ["-y", "@modelcontextprotocol/server-github"]
            }
          }
        }
        """.trimIndent()
        mutableStateOf(settingsMap[ChatViewModel.KEY_MCP_SERVERS_JSON] ?: defaultJson)
    }

    // Web Server
    var webServerEnabled by remember(settingsMap) {
        mutableStateOf(settingsMap[ChatViewModel.KEY_WEB_SERVER_ENABLED] ?: "false")
    }

    // Expansion panels state
    var expandedModels by remember { mutableStateOf(false) }
    var expandedProviders by remember { mutableStateOf(false) }
    var expandedSearch by remember { mutableStateOf(false) }
    var expandedSpeech by remember { mutableStateOf(false) }
    var expandedMcp by remember { mutableStateOf(false) }
    var expandedWebServer by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClicked) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // General Title
            Text(
                text = "SYSTEM CONFIGURATIONS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(bottom = 4.dp)
            )

            // 1. MODELS & SERVICES
            SettingsCategoryCard(
                title = "⚙️ Models & Services",
                description = "Set default models and system prompts",
                isExpanded = expandedModels,
                onHeaderClick = { expandedModels = !expandedModels }
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = fastModelInput,
                        onValueChange = {
                            fastModelInput = it
                            viewModel.saveSettingValue(ChatViewModel.KEY_FAST_MODEL, it)
                        },
                        label = { Text("Default Fast Model") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = thinkingModelInput,
                        onValueChange = {
                            thinkingModelInput = it
                            viewModel.saveSettingValue(ChatViewModel.KEY_THINKING_MODEL, it)
                        },
                        label = { Text("Default Thinking Model") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = fastPromptInput,
                        onValueChange = {
                            fastPromptInput = it
                            viewModel.saveSettingValue(ChatViewModel.KEY_FAST_SYSTEM_PROMPT, it)
                        },
                        label = { Text("Fast Mode System Prompt") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3,
                        maxLines = 5
                    )

                    OutlinedTextField(
                        value = thinkingPromptInput,
                        onValueChange = {
                            thinkingPromptInput = it
                            viewModel.saveSettingValue(ChatViewModel.KEY_THINKING_SYSTEM_PROMPT, it)
                        },
                        label = { Text("Thinking Mode System Prompt") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3,
                        maxLines = 5
                    )
                }
            }

            // 2. PROVIDERS
            SettingsCategoryCard(
                title = "🧠 Providers",
                description = "Configure OpenRouter credentials and bases",
                isExpanded = expandedProviders,
                onHeaderClick = { expandedProviders = !expandedProviders }
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = apiKeyInput,
                        onValueChange = {
                            apiKeyInput = it
                            viewModel.saveSettingValue(ChatViewModel.KEY_API_KEY, it)
                        },
                        label = { Text("Provider API Key") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = { Text("sk-or-v1-...") }
                    )

                    OutlinedTextField(
                        value = baseEndpointInput,
                        onValueChange = {
                            baseEndpointInput = it
                            viewModel.saveSettingValue(ChatViewModel.KEY_BASE_ENDPOINT, it)
                        },
                        label = { Text("Base URL Endpoint") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            }

            // 3. SEARCH SERVICE
            SettingsCategoryCard(
                title = "🔍 Search Service",
                description = "Configure Tavily, Brave or Custom JavaScript queries",
                isExpanded = expandedSearch,
                onHeaderClick = { expandedSearch = !expandedSearch }
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Select Search Provider:", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("None", "Tavily", "Brave", "Custom JS").forEach { type ->
                            FilterChip(
                                selected = searchServiceType == type,
                                onClick = {
                                    searchServiceType = type
                                    viewModel.saveSettingValue(ChatViewModel.KEY_SEARCH_SERVICE_TYPE, type)
                                },
                                label = { Text(type) }
                            )
                        }
                    }

                    if (searchServiceType == "Tavily" || searchServiceType == "Brave") {
                        OutlinedTextField(
                            value = searchServiceKey,
                            onValueChange = {
                                searchServiceKey = it
                                viewModel.saveSettingValue(ChatViewModel.KEY_SEARCH_SERVICE_KEY, it)
                            },
                            label = { Text("$searchServiceType API Key") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    } else if (searchServiceType == "Custom JS") {
                        OutlinedTextField(
                            value = """
                            function queryGoogle(prompt) {
                              const searchUrl = "https://www.google.com/search?q=" + encodeURIComponent(prompt);
                              return fetch(searchUrl).then(r => r.text());
                            }
                            """.trimIndent(),
                            onValueChange = {},
                            label = { Text("Custom JS Query Script") },
                            modifier = Modifier.fillMaxWidth(),
                            textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
                            minLines = 4,
                            maxLines = 6,
                            readOnly = true
                        )
                    }
                }
            }

            // 4. SPEECH SERVICES
            SettingsCategoryCard(
                title = "📢 Speech Services",
                description = "Configure TTS and STT options",
                isExpanded = expandedSpeech,
                onHeaderClick = { expandedSpeech = !expandedSpeech }
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Text-to-Speech (TTS) Provider:", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("SystemDefault", "ElevenLabs", "Edge TTS").forEach { type ->
                            FilterChip(
                                selected = speechTtsProvider == type,
                                onClick = {
                                    speechTtsProvider = type
                                    viewModel.saveSettingValue(ChatViewModel.KEY_SPEECH_TTS_PROVIDER, type)
                                },
                                label = { Text(type) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text("Speech-to-Text (STT) Provider:", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("SystemDefault", "OpenAI Whisper").forEach { type ->
                            FilterChip(
                                selected = speechSttProvider == type,
                                onClick = {
                                    speechSttProvider = type
                                    viewModel.saveSettingValue(ChatViewModel.KEY_SPEECH_STT_PROVIDER, type)
                                },
                                label = { Text(type) }
                            )
                        }
                    }
                }
            }

            // 5. MODEL CONTEXT PROTOCOL (MCP)
            SettingsCategoryCard(
                title = "🔧 Model Context Protocol (MCP)",
                description = "Manage external server JSON tools",
                isExpanded = expandedMcp,
                onHeaderClick = { expandedMcp = !expandedMcp }
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Register active tools and integrations below:", fontSize = 13.sp)
                    OutlinedTextField(
                        value = mcpServersJson,
                        onValueChange = {
                            mcpServersJson = it
                            viewModel.saveSettingValue(ChatViewModel.KEY_MCP_SERVERS_JSON, it)
                        },
                        label = { Text("MCP JSON Config") },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
                        minLines = 4,
                        maxLines = 6
                    )
                }
            }

            // 6. WEB SERVER
            SettingsCategoryCard(
                title = "🌐 Web Server",
                description = "Toggle local RikkaHub network control",
                isExpanded = expandedWebServer,
                onHeaderClick = { expandedWebServer = !expandedWebServer }
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Allow RikkaHub Access", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Share context or queries via local LAN", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = webServerEnabled == "true",
                            onCheckedChange = {
                                val str = if (it) "true" else "false"
                                webServerEnabled = str
                                viewModel.saveSettingValue(ChatViewModel.KEY_WEB_SERVER_ENABLED, str)
                            },
                            modifier = Modifier.testTag("rikkahub_switch")
                        )
                    }

                    if (webServerEnabled == "true") {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Card(
                                            colors = CardDefaults.cardColors(containerColor = Color(0xFF4CAF50)),
                                            shape = RoundedCornerShape(50),
                                            modifier = Modifier.size(6.dp)
                                        ) {}
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("RikkaHub Server is active", color = Color(0xFF2E7D32), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Endpoint URL: http://192.168.1.50:8080", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color(0xFF1B5E20))
                                }
                                IconButton(
                                    onClick = {
                                        val clip = ClipData.newPlainText("RikkaHub Link", "http://192.168.1.50:8080")
                                        clipboardManager.setPrimaryClip(clip)
                                        Toast.makeText(context, "Link copied", Toast.LENGTH_SHORT).show()
                                    }
                                ) {
                                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy link", tint = Color(0xFF2E7D32), modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // About Application Card Link
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .clickable(onClick = onAboutClicked)
                    .testTag("about_app_card"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("ℹ️", fontSize = 24.sp)
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text("About RikkaHub & Device Hype", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text("View developer details and license logs", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsCategoryCard(
    title: String,
    description: String,
    isExpanded: Boolean,
    onHeaderClick: () -> Unit,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onHeaderClick)
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    Text(text = description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = if (isExpanded) "Collapse" else "Expand"
                )
            }

            AnimatedVisibility(
                visible = isExpanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.15f))
                        .padding(16.dp)
                ) {
                    content()
                }
            }
        }
    }
}
