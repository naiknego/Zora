package com.example.ui.screens

import android.content.Context
import android.content.ClipData
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ChatMessage
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    sessionTitle: String,
    messages: List<ChatMessage>,
    activeMode: String,
    isTyping: Boolean,
    errorMessage: String?,
    onBackClicked: () -> Unit,
    onModeChanged: (String) -> Unit,
    onSendMessage: (String) -> Unit
) {
    var textInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current
    val clipboardManager = remember {
        context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
    }

    // Auto-scroll to bottom on new messages
    LaunchedEffect(messages.size, isTyping) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Soft ambient background glowing mesh matching RikkaHub's premium design
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .alpha(0.18f)
        ) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF7B2CBF), Color.Transparent),
                    radius = size.width * 0.85f
                ),
                radius = size.width * 0.85f,
                center = androidx.compose.ui.geometry.Offset(size.width * 0.1f, size.height * 0.1f)
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFFF72585), Color.Transparent),
                    radius = size.width * 0.7f
                ),
                radius = size.width * 0.7f,
                center = androidx.compose.ui.geometry.Offset(size.width * 0.85f, size.height * 0.75f)
            )
        }

        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = sessionTitle,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (activeMode == "thinking") "Deep-Reasoning active" else "Fast-Response active",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f)
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = onBackClicked,
                            modifier = Modifier
                                .padding(start = 8.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    },
                    actions = {
                        Row(
                            modifier = Modifier.padding(end = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            ModeTogglePill(
                                activeMode = activeMode,
                                onModeChanged = onModeChanged
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.Transparent,
                        scrolledContainerColor = Color.Transparent
                    )
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    if (messages.isEmpty() && !isTyping) {
                        EmptyConversationState(
                            onSuggestionClicked = { suggestion ->
                                textInput = suggestion
                                onSendMessage(suggestion)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                        )
                    } else {
                        // Message List
                        LazyColumn(
                            state = listState,
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 90.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            items(messages, key = { it.id }) { message ->
                                val animatedMessageRow = message
                                AnimatedMessageRow(message = message, onCopyClicked = { text ->
                                    val clip = ClipData.newPlainText("RikkaHub AI", text)
                                    clipboardManager.setPrimaryClip(clip)
                                    Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
                                })
                            }

                            if (isTyping) {
                                item {
                                    ThinkingIndicatorRow(mode = activeMode)
                                }
                            }
                        }
                    }

                    // Error Message Bar
                    errorMessage?.let { error ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.9f)),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 6.dp)
                                .border(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.2f), RoundedCornerShape(14.dp))
                        ) {
                            Text(
                                text = error,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(14.dp)
                            )
                        }
                    }

                    // Floating Input capsule bar
                    InputBar(
                        text = textInput,
                        onTextChanged = { textInput = it },
                        onSendClicked = {
                            if (textInput.isNotBlank()) {
                                onSendMessage(textInput)
                                textInput = ""
                            }
                        }
                    )
                }

                // Quick Scroll-To-Bottom FAB
                val isScrollRequired = remember {
                    derivedStateOf {
                        val lastVisibleItem = listState.layoutInfo.visibleItemsInfo.lastOrNull()
                        lastVisibleItem == null || lastVisibleItem.index < messages.size - 1
                    }
                }

                AnimatedVisibility(
                    visible = isScrollRequired.value && messages.isNotEmpty(),
                    enter = scaleIn(animationSpec = tween(200)) + fadeIn(),
                    exit = scaleOut(animationSpec = tween(200)) + fadeOut(),
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(bottom = 100.dp, end = 20.dp)
                ) {
                    FloatingActionButton(
                        onClick = {
                            coroutineScope.launch {
                                listState.animateScrollToItem(messages.size - 1)
                            }
                        },
                        modifier = Modifier.size(42.dp),
                        shape = CircleShape,
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f),
                        contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ) {
                        Icon(
                            imageVector = Icons.Default.KeyboardArrowDown,
                            contentDescription = "Scroll to bottom",
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ModeTogglePill(
    activeMode: String,
    onModeChanged: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
            .border(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f), RoundedCornerShape(50))
            .padding(3.dp)
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(if (activeMode == "fast") MaterialTheme.colorScheme.primary else Color.Transparent)
                .clickable { onModeChanged("fast") }
                .padding(horizontal = 12.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "⚡ Fast",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (activeMode == "fast") MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(if (activeMode == "thinking") MaterialTheme.colorScheme.secondary else Color.Transparent)
                .clickable { onModeChanged("thinking") }
                .padding(horizontal = 12.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "🧠 Think",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (activeMode == "thinking") MaterialTheme.colorScheme.onSecondary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun AnimatedMessageRow(
    message: ChatMessage,
    onCopyClicked: (String) -> Unit
) {
    val scale = remember { Animatable(0.93f) }
    val opacity = remember { Animatable(0f) }

    LaunchedEffect(key1 = message.id) {
        scale.animateTo(1.0f, animationSpec = tween(durationMillis = 350, easing = EaseOutBack))
    }
    LaunchedEffect(key1 = message.id) {
        opacity.animateTo(1.0f, animationSpec = tween(durationMillis = 250))
    }

    Box(
        modifier = Modifier.graphicsLayer(
            scaleX = scale.value,
            scaleY = scale.value,
            alpha = opacity.value
        )
    ) {
        MessageRow(message = message, onCopyClicked = onCopyClicked)
    }
}

@Composable
fun MessageRow(
    message: ChatMessage,
    onCopyClicked: (String) -> Unit
) {
    val isUser = message.role == "user"

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!isUser) {
            // Little Assistant Badge
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(
                        brush = Brush.linearGradient(
                            colors = listOf(Color(0xFF7B2CBF), Color(0xFFF72585))
                        )
                    )
                    .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                    .padding(4.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Z",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
        }

        val bubbleShape = if (isUser) {
            RoundedCornerShape(20.dp, 20.dp, 4.dp, 20.dp)
        } else {
            RoundedCornerShape(20.dp, 20.dp, 20.dp, 4.dp)
        }

        // Custom cyber-style gradient for User bubbles & Glassmorphic layout for Assistant bubbles
        val bubbleModifier = if (isUser) {
            Modifier
                .shadow(2.dp, bubbleShape)
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(Color(0xFF7B2CBF), Color(0xFFF72585))
                    ),
                    shape = bubbleShape
                )
                .border(
                    1.dp,
                    brush = Brush.linearGradient(
                        colors = listOf(Color.White.copy(alpha = 0.25f), Color.Transparent)
                    ),
                    shape = bubbleShape
                )
        } else {
            Modifier
                .shadow(1.dp, bubbleShape)
                .background(
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.55f),
                    shape = bubbleShape
                )
                .border(
                    1.dp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f),
                    shape = bubbleShape
                )
        }

        val textColor = if (isUser) {
            Color.White
        } else {
            MaterialTheme.colorScheme.onSurface
        }

        Column(
            modifier = Modifier.weight(1f, fill = false),
            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
        ) {
            Box(
                modifier = bubbleModifier.padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                SelectionContainer {
                    FormattedMessageContent(
                        text = message.content,
                        textColor = textColor,
                        onCopyClicked = onCopyClicked
                    )
                }
            }
        }

        if (isUser) {
            Spacer(modifier = Modifier.width(8.dp))
        }
    }
}

@Composable
fun FormattedMessageContent(
    text: String,
    textColor: Color,
    onCopyClicked: (String) -> Unit
) {
    // Basic Markdown parser splitting code blocks by ```
    val parts = remember(text) { text.split("```") }

    Column {
        parts.forEachIndexed { index, part ->
            if (index % 2 == 1) {
                // Code block formatting
                val lines = part.split("\n")
                val lang = lines.firstOrNull()?.trim() ?: ""
                val code = lines.drop(1).joinToString("\n").trim()

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .border(
                            1.dp,
                            Color.White.copy(alpha = 0.08f),
                            RoundedCornerShape(14.dp)
                        ),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0E0F16)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF181A26))
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = lang.uppercase().ifEmpty { "CODE" },
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF00F5D4)
                            )
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { onCopyClicked(code) }
                                    .padding(horizontal = 6.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "Copy code",
                                    tint = Color.LightGray,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Copy", fontSize = 11.sp, color = Color.LightGray, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text(
                            text = code,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp,
                            color = Color(0xFFD4D4D4),
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                }
            } else {
                // Text rendering with bold formatting parsed
                if (part.isNotEmpty()) {
                    Text(
                        text = parseMarkdownInline(part),
                        fontSize = 15.sp,
                        lineHeight = 23.sp,
                        color = textColor
                    )
                }
            }
        }
    }
}

// Simple inline formatter for markdown: **bold** and *italic*
fun parseMarkdownInline(text: String): AnnotatedString {
    return buildAnnotatedString {
        var cursor = 0
        while (cursor < text.length) {
            val boldIndex = text.indexOf("**", cursor)
            val italicIndex = text.indexOf("*", cursor)

            if (boldIndex != -1 && (italicIndex == -1 || boldIndex < italicIndex)) {
                // Handle bold
                append(text.substring(cursor, boldIndex))
                val endBold = text.indexOf("**", boldIndex + 2)
                if (endBold != -1) {
                    val boldText = text.substring(boldIndex + 2, endBold)
                    pushStyle(SpanStyle(fontWeight = FontWeight.Bold))
                    append(boldText)
                    pop()
                    cursor = endBold + 2
                } else {
                    append("**")
                    cursor = boldIndex + 2
                }
            } else if (italicIndex != -1) {
                // Handle italic
                append(text.substring(cursor, italicIndex))
                val endItalic = text.indexOf("*", italicIndex + 1)
                if (endItalic != -1) {
                    val italicText = text.substring(italicIndex + 1, endItalic)
                    pushStyle(SpanStyle(fontStyle = FontStyle.Italic))
                    append(italicText)
                    pop()
                    cursor = endItalic + 1
                } else {
                    append("*")
                    cursor = italicIndex + 1
                }
            } else {
                // Remainder of text
                append(text.substring(cursor))
                break
            }
        }
    }
}

@Composable
fun ThinkingIndicatorRow(mode: String) {
    val infiniteTransition = rememberInfiniteTransition(label = "thinkingAnim")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(750, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Start,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(Color(0xFF7B2CBF), Color(0xFFF72585))
                    )
                )
                .padding(4.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("Z", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color.White)
        }
        Spacer(modifier = Modifier.width(10.dp))

        Card(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp, 20.dp, 20.dp, 4.dp))
                .border(
                    1.dp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f),
                    shape = RoundedCornerShape(20.dp, 20.dp, 20.dp, 4.dp)
                ),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.55f))
        ) {
            Row(
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .alpha(alpha),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (mode == "thinking") "🧠 Reasoning carefully" else "⚡ Formulating response",
                    fontSize = 14.sp,
                    fontStyle = FontStyle.Italic,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.width(6.dp))
                BouncingDots()
            }
        }
    }
}

@Composable
fun BouncingDots() {
    val dotSize = 5.dp
    val travelDistance = 5.dp
    val duration = 650

    val infiniteTransition = rememberInfiniteTransition(label = "bouncing_dots")

    val animations = List(3) { index ->
        infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = keyframes {
                    durationMillis = duration
                    0.0f at (index * 130) with EaseInOutSine
                    0.5f at (index * 130 + 160) with EaseInOutSine
                    1.0f at (index * 130 + 320) with EaseInOutSine
                },
                repeatMode = RepeatMode.Reverse
            ),
            label = "dot_$index"
        )
    }

    Row(
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        animations.forEach { anim ->
            val yOffset = - (anim.value * travelDistance.value).dp
            Box(
                modifier = Modifier
                    .size(dotSize)
                    .offset(y = yOffset)
                    .background(
                        brush = Brush.linearGradient(
                            colors = listOf(Color(0xFF7B2CBF), Color(0xFFF72585))
                        ),
                        shape = CircleShape
                    )
            )
        }
    }
}

@Composable
fun EmptyConversationState(
    onSuggestionClicked: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val suggestions = listOf(
        "Explain quantum computing in 3 sentences ⚡",
        "Write a Kotlin room database model block 🧠",
        "Give me 5 motivational productivity rules ⚡",
        "Translate 'Have a nice day' to German & Japanese 🧠"
    )

    Box(
        modifier = modifier.padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            EmptyState(
                title = "Say hello to RikkaHub!",
                description = "Choose one of the quick suggestions below or write any prompt to begin.",
                iconString = "👋",
                modifier = Modifier.wrapContentHeight()
            )

            Spacer(modifier = Modifier.height(28.dp))

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                suggestions.forEach { suggestion ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSuggestionClicked(suggestion.substringBeforeLast(" ")) }
                            .border(
                                width = 1.dp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f),
                                shape = RoundedCornerShape(18.dp)
                            )
                            .testTag("suggestion_chip_${suggestion.take(10)}"),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.55f)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 18.dp, vertical = 16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = suggestion.substringBeforeLast(" "),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = suggestion.takeLast(1),
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun InputBar(
    text: String,
    onTextChanged: (String) -> Unit,
    onSendClicked: () -> Unit
) {
    Surface(
        tonalElevation = 8.dp,
        color = Color.Transparent,
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Capsule Text Field
            OutlinedTextField(
                value = text,
                onValueChange = onTextChanged,
                placeholder = { Text("Ask anything...", color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)) },
                modifier = Modifier
                    .weight(1f)
                    .border(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f),
                        shape = RoundedCornerShape(26.dp)
                    )
                    .testTag("chat_input_text_field"),
                maxLines = 5,
                shape = RoundedCornerShape(26.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.55f),
                    focusedBorderColor = Color(0xFF7B2CBF),
                    unfocusedBorderColor = Color.Transparent
                )
            )

            Spacer(modifier = Modifier.width(10.dp))

            // Glowing Cyber-gradient Send Button
            val sendButtonBg = if (text.isNotBlank()) {
                Brush.linearGradient(colors = listOf(Color(0xFF7B2CBF), Color(0xFFF72585)))
            } else {
                Brush.linearGradient(colors = listOf(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f), MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)))
            }

            IconButton(
                onClick = onSendClicked,
                enabled = text.isNotBlank(),
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(sendButtonBg)
                    .border(
                        1.dp,
                        color = if (text.isNotBlank()) Color.White.copy(alpha = 0.25f) else Color.Transparent,
                        shape = CircleShape
                    )
                    .testTag("send_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Send",
                    tint = if (text.isNotBlank()) Color.White else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
